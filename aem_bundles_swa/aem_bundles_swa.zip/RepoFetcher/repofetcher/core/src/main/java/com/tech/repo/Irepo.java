package com.tech.repo;

public interface Irepo{
	public String getRepositories(String username);
}