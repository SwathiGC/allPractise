package com.tech.call;


public interface IcallService{
	public String myGetRequest();
}